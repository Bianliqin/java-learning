package com.liqinbian.sm.service.impl;

import com.liqinbian.sm.dao.DepartmentDao;
import com.liqinbian.sm.entity.Department;
import com.liqinbian.sm.factory.DaoFactory;
import com.liqinbian.sm.service.DepartmentService;

import java.sql.SQLException;
import java.util.List;

/**
 * @ClassName DepartmentServiceImpl
 * @Description TODO
 * @Author huachengyu
 * @Date 2020/11/18
 **/
public class DepartmentServiceImpl implements DepartmentService {
    private final DepartmentDao departmentDao = DaoFactory.getDepartmentDaoInstance();
    @Override
    public List<Department> selectAll(){
        List<Department> departmentList = null;
        try {
            departmentList = departmentDao.getAll();
        }catch (SQLException e){
            System.out.print("查询院系信息出现异常");
        }
        return departmentList;
    }
}
